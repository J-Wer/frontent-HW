Источник иконок: https://fontawesome.com/v5.15/icons?d=gallery&p=2

This SVG Icon Requires Attribution
Before you download, this icon is licensed under the Creative Commons Attribution 4.0 International license and requires that you comply with the following:

You must give appropriate credit, provide a link to the license https://fontawesome.com/license, and indicate if changes were made. You may do so in any reasonable manner, but not in any way that suggests the licensor endorses you or your use.

This brand icon is a trademark of the respective owner. The use of this trademark does not indicate endorsement of the trademark holder by Font Awesome, nor vice versa. Please do not use brand logos for any purpose except to represent the company, product, or service to which they refer.

Добавление от меня: changes were made — во всех иконках я заменил цвет на белый.